import React from 'react'
import './assets/css/base/base.css'

function App() {
  return (
  <>

  </>
  )
}

export default App
